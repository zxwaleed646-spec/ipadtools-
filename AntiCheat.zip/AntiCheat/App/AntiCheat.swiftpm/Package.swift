// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "AntiCheat",
    platforms: [
        .iOS("16.0")
    ],
    products: [
        .iOSApplication(
            name: "AntiCheat",
            targets: ["AppModule"],
            bundleIdentifier: "com.example.anticheat",   // غيّره لمعرّف خاص فيك
            teamIdentifier: "",                           // Xcode يعبّيه لك من حسابك
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .cloud),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ]
)
